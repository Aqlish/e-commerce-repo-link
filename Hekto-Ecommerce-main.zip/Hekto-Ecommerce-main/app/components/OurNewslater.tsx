import React from 'react'
// import Button from './Button'


const OurNewslater = () => {
    return (
        <section className='pt-28 pb-16 bg-[url("/backpic1.png")] bg-cover bg-center bg-no-repeat'>
            <div className='md:max-w-[50%] max-w-[96%] mx-auto h-full flex justify-center text-center items-center flex-col gap-4'>
                <h2 className='md:text-4xl text-2xl font-bold text-[#151875]'>Get Leatest Update By Subscribe
                    0ur Newslater</h2>
                {/* <Button size={"lg"} variant={"secondary"} >Shop Now</Button> */}
            </div>
        </section>
    )
}

export default OurNewslater