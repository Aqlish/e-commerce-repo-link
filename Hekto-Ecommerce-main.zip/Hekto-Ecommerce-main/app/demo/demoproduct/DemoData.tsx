const demoProductData = [
    {
        pic: "/demo1.png",
        title: "Ut Diam consequat",
        color: "Brown",
        size: "XL",
        price: "$32.00"
    },
    {
        pic: "/demo2.png",
        title: "Ut Diam consequat",
        color: "Brown",
        size: "XL",
        price: "$32.00"
    },
    {
        pic:"/demo3.png",
        title: "Ut Diam consequat",
        color: "Brown",
        size: "XL",
        price: "$32.00"
    },
    {
        pic: "/demo4.png",
        title: "Ut Diam consequat",
        color: "Brown",
        size: "XL",
        price: "$32.00"
    },
    {
        pic: "/demo5.png",
        title: "Ut Diam consequat",
        color: "Brown",
        size: "XL",
        price: "$32.00"
    },
]

export default demoProductData