import React from "react";


import Logos from "../components/Logos";
const LoginPage = () => {
  return (
    <main>
      {/* <Heading heading="My Account" /> */}
      {/* <Login /> */}
      <Logos />
    </main>
  );
};

export default LoginPage;
